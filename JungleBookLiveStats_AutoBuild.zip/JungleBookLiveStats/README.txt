JungleBookLiveStats

This Android prototype:
1. Requests screen-capture permission.
2. Displays a small overlay while the game is open.
3. OCRs visible text and counts explicit WIN/WON and LOSS/LOSE/LOST labels.
4. Shows statistics for the last 50, 100 and 500 detected results.

Important:
- It does NOT predict the next spin or alter the game.
- The current version is designed for text-based results.
- If the game's history uses animal/symbol icons instead of WIN/LOSS text,
  the OCR detector must be replaced with image/template recognition for those
  exact symbols. Provide a clear screenshot of the result-history strip to
  calibrate that detector.
- Build with Android Studio. Open this folder as a project and Run.
