package com.example.junglebookstats

import android.app.*
import android.content.Intent
import android.graphics.PixelFormat
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.view.*
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.ArrayDeque

class CaptureService : Service() {
    private var projection: MediaProjection? = null
    private var reader: ImageReader? = null
    private var overlay: View? = null
    private val history = ArrayDeque<Boolean>()
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        createChannel()
        startForeground(1, notification())

        val code = intent?.getIntExtra("resultCode", Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        val data = intent?.getParcelableExtra<Intent>("data") ?: return START_NOT_STICKY
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(code, data)

        val dm = resources.displayMetrics
        reader = ImageReader.newInstance(dm.widthPixels, dm.heightPixels,
            PixelFormat.RGBA_8888, 2)

        reader!!.setOnImageAvailableListener({ r ->
            val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            // This first version OCRs the full screen. For your game, crop the result/history
            // rectangle once its exact position is known.
            val bmp = imageToBitmap(image)
            image.close()
            if (bmp != null) {
                val input = InputImage.fromBitmap(bmp, 0)
                recognizer.process(input)
                    .addOnSuccessListener { text ->
                        val u = text.text.uppercase()
                        val wins = Regex("\bWIN\b|\bWON\b").findAll(u).count()
                        val losses = Regex("\bLOSS\b|\bLOSE\b|\bLOST\b").findAll(u).count()
                        repeat(wins) { add(true) }
                        repeat(losses) { add(false) }
                        updateOverlay()
                    }
            }
        }, Handler(Looper.getMainLooper()))

        projection!!.createVirtualDisplay(
            "LiveSpinStats", dm.widthPixels, dm.heightPixels, dm.densityDpi,
            0, reader!!.surface, null, null
        )
        showOverlay()
        return START_STICKY
    }

    private fun add(win: Boolean) {
        history.addLast(win)
        while (history.size > 500) history.removeFirst()
    }

    private fun updateOverlay() {
        val v = overlay as? TextView ?: return
        val s = StringBuilder()
        for (n in listOf(50, 100, 500)) {
            val a = history.toList().takeLast(n)
            if (a.isEmpty()) {
                s.append("Last $n: no data\n")
            } else {
                val w = a.count { it }
                val l = a.size - w
                s.append("Last $n: W ${"%.1f".format(w*100.0/a.size)}%  ")
                 .append("L ${"%.1f".format(l*100.0/a.size)}%\n")
            }
        }
        v.text = s.toString()
    }

    private fun showOverlay() {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val tv = TextView(this).apply {
            text = "Live Spin Stats\nWaiting for result text..."
            textSize = 15f
            setPadding(18, 12, 18, 12)
            setBackgroundColor(0xCC111111.toInt())
            setTextColor(0xFFFFFFFF.toInt())
        }
        overlay = tv
        val type = if (Build.VERSION.SDK_INT >= 26)
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        else WindowManager.LayoutParams.TYPE_PHONE
        val p = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT
        )
        p.gravity = Gravity.TOP or Gravity.START
        p.x = 20; p.y = 120
        wm.addView(tv, p)
    }

    private fun imageToBitmap(image: android.media.Image): android.graphics.Bitmap? {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val bmp = android.graphics.Bitmap.createBitmap(
            image.width + rowPadding / pixelStride,
            image.height,
            android.graphics.Bitmap.Config.ARGB_8888
        )
        bmp.copyPixelsFromBuffer(buffer)
        return android.graphics.Bitmap.createBitmap(bmp, 0, 0, image.width, image.height)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val c = NotificationChannel("stats", "Live Spin Stats",
                NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(c)
        }
    }

    private fun notification(): Notification =
        Notification.Builder(this, "stats")
            .setContentTitle("Live Spin Stats")
            .setContentText("Screen reader is running")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .build()

    override fun onDestroy() {
        overlay?.let { (getSystemService(WINDOW_SERVICE) as WindowManager).removeView(it) }
        reader?.close()
        projection?.stop()
        recognizer.close()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null
}
